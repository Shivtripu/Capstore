
package com.cg.capstore.repo;

import java.util.Random;

import org.springframework.stereotype.Repository;

@Repository
public class InviteFriendRepoImpl implements IInviteFriendRepo{

	@Override
	public String inviteFriend(String mobileNo) {

		Random rand=new Random();
		return Integer.toString(rand.nextInt(10))+"Shivam";
	}

}
